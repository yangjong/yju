---
layout: redirect
redirect: docs/bazel-user-manual.html
---
