---
layout: redirect
redirect: docs/skylark/cookbook.html
---
