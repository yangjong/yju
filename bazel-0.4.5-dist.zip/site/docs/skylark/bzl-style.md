---
layout: redirect
redirect: docs/skylark/bzl-style.html
---
