# Our documentation is in another directory.

Bazel's documentation is now versioned. This directory contains redirects to
the latest version of each page.

To make changes to Bazel documentation at HEAD, please edit the files under
`versions/master`. Once a release is cut, the docs in the `master` directory
will be snapshotted and copied into a versioned directory for the release.

Happy documenting!
