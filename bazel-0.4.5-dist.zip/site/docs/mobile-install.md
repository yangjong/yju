---
layout: redirect
redirect: docs/mobile-install.html
---
