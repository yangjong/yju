---
layout: posts
title: We are now bazel.build!
---

As you might have seen either in our
[0.4 announcement](/blog/2016/11/02/0.4.0-release.html) or simply by going to
our website, we have recently switched over to the
[bazel.build](https://bazel.build) domain name.

We decided to switch over to the new .build top-level domain, which reflects
what Bazel is for: building!

Our old domain, [bazel.io](https://bazel.io), will redirect to
[bazel.build](https://bazel.build) for the forseenable future.
